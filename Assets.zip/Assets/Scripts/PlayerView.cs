using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerView : MonoBehaviour
{
    public PlayerModel PlayerModel { get; private set; }

    public void Init(PlayerModel playerModel)
    {
        PlayerModel = playerModel;
        PlayerModel.Collided += OnCollided;
        Debug.Log("в playerView мы подписались на событие модели");
    }

    public void OnDestroy()
    {
        PlayerModel.Collided -= OnCollided;
        Debug.Log("в playerView мы отписались от события модели");
    }

    private void OnCollided(Collider obj)
    {
        Debug.Log(" Player View узнала о столкновении модели и что-то делает");
    }
}