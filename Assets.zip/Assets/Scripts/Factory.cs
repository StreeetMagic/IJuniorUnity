using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Factory
{
    public PlayerModel CreatePlayerModel()
    {
        return new PlayerModel();
    }

    public PlayerView CreatePlayerView()
    {
        var player = Resources.Load<PlayerView>("Player");
        return Object.Instantiate(player);
    }

    public CollisionDetector CreateCollisionDetector()
    {
        var collisionDetector = Resources.Load<CollisionDetector>("CollisionDetector");
        return Object.Instantiate(collisionDetector);
    }
}