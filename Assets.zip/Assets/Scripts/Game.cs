using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Game : MonoBehaviour
{
    private Factory _factory;
    private PlayerModel _playerModel;

    void Start()
    {
        _playerModel = new PlayerModel();
        _factory = new Factory();
    }

    private void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            PlayerView player = _factory.CreatePlayerView();
            CollisionDetector collisionDetector = _factory.CreateCollisionDetector();
            player.Init(_playerModel);

            collisionDetector.transform.SetParent(player.transform);
            collisionDetector.PlayerModel = _playerModel;
        }
    }
}