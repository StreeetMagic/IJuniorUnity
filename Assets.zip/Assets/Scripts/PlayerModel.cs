using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerModel
{
    public event Action<Collider> Collided;

    public void Collide(Collider other)
    {
        Debug.Log(" Модель столкнулась и сообщает об этом через событие");
        Collided?.Invoke(other);
    }
}