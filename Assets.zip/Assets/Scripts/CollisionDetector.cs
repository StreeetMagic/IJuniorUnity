using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CollisionDetector : MonoBehaviour
{
    public PlayerModel PlayerModel { get; set; }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.C))
        {
            Debug.Log("Коллижн детектор прочитал столкновение и оповестил модель");
            PlayerModel.Collide(GetComponent<Collider>());
        }
    }
}